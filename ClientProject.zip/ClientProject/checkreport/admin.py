from django.contrib import admin

# Register your models here.
from .models import ClientModel
class ClientAdmin(admin.ModelAdmin):
    list_display = ('token', 'name','phone_number', 'status','TestType')
admin.site.register(ClientModel, ClientAdmin)
