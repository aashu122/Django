from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from django.shortcuts import render
from .models import ClientModel,GENDER_CHOICES,STATUS_CHOICES
from cl import settings

# Create your views here.
def home(request):
    if request.is_ajax():
        token = request.GET.get('token', None)
        exist = ClientModel.objects.filter(token__iexact=token).exists()
        if exist:
            ClienData = ClientModel.objects.get(token=token)
            data = dict(
                exist=exist,
                token=ClienData.token,
                name=ClienData.name,
                gender=ClienData.gender,
                phone=ClienData.phone_number,
                status= ClienData.status,
                TestType=ClienData.TestType,
            )
            data['File']= str(settings.MEDIA_URL)+str(ClienData.document)
        else:
            data = dict(
                exist=exist
            )
        return JsonResponse(data)

    if request.method == 'GET':
        return render(request,'index.html')
    elif request.method == 'POST':
        pass
