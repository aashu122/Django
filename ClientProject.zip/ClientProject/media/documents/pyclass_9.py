# frozen set
# here it will convert into immutable
"""s3 = [10,20,30,40]
fr = frozenset(s3)
print("fr===",fr,type(fr))
fr[1] = 12
"""
# procedural programming  -->
# Function
"""def add(a,b):
    print(a+b)
add(20,40)"""
#add(10,20)
#add(10,50)

# functions
# 1 user defined ,2. inbuilt function
# Function is basically a group of statement which is use by the user again and again.
# Function is thing which accept data perform a logic and return the output.
# Naming convention of function is always start with small letter
"""def hello():
    a = int(input("Enter the number: "))
    b = int(input("Enter the next number: "))
    print("a+b",a+b)
    print("a-b",a-b)
    print("a*b",a*b)
for i in range(10,20):
    print(i)
hello()
"""
#parameter and argument
"""def my(a,b): # a nd b are parameters
    print("a>>>>",a,"b>>>>>",b)
my(10,20) # 10 and 20 are the aguments """

# parameterized (argument based) and non-parameterized(argument based) functions
# positional argument function
"""def check(a,b,c,d,e):
    print("hello",a,"go for",b,"use",c,d,e)
    print("I am good")
check(1,2,3,4,5)
check("Ashu","Jack","Sam","Alex","Ram")"""
# keyword based argument function
"""def new(name,age,salary):
    print("Hello my name is {} and my age {} and salary is {}".format(name,age,salary))
new(age = 20,name = "Ashu",salary = 4523) # keyword argument
# Now to try to operate keyword and positional argument at the same time
# case -1
new("ashu",20,salary = 456123)
"""
