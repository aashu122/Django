#Python
# Features
# 1. Simple
# 2. Dynamic typed Language
# Automatic Memory Management
"""a = 15463
print(id(a))
b = 6238746
print(id(b))
print("Hello Python")
"""
# Variable
"""var  = 123
var1 = 44
#4var = 4566
#var@var = 789
import keyword
print(keyword.kwlist)
print(len(keyword.kwlist))

"""
# Type specfier
# %d --- integer
# %f --- float
# %s --- string
"""a  = 74
b = "ashu"
print(a,b)
print("Value of a is %d and b is %s"%(a,b))
# Format
print("Value of a {} and b {}".format(a,b))

"""
"""
s = int(input("Enter the integer number: "))
print(s)
"""
#s = input("Enter the string: ")
#s = float(input("Enter the float number:: "))
"""strg = eval(input("Enter any data type: "))
print(strg,type(strg))
"""
# Type of Operator
# 1. arithmetic operator
# 2. Assignment
# 3 Comparison
# 4. Logical
# 5 Membership
# identity
# bitwise
# Ternary Operator

# Control Statement
# if else elif
"""num = int(input("Enter the number: "))
if(num%2 == 0):
    print(num,"num is even")

else:
    print(num,"num is odd")
"""

# nested if elif else statement
num = int(input("Enter a number: "))
if(num>=0):
    if(num == 0):
        print("Number is equal to zero")
    else:
        print("Number is positive")
else:
    print("Number is negative")
    
